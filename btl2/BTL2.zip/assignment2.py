# Them cac thu vien neu can

def assign(file_input, file_output):
    # read input
    # run algorithm
    # write output
    return


assign('input.txt', 'output.txt')
